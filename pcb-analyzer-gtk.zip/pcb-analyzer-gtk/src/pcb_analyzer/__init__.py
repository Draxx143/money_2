"""PCB Analyzer — core package."""
